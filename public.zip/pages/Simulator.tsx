import React, { useState, useRef, useCallback, useEffect } from 'react';
import {
  Upload,
  Camera,
  RefreshCcw,
  Download,
  Layers,
  AlertCircle,
  Palette,
  Check,
  MousePointer2,
  PenTool,
  Cpu,
  Plus,
  Trash2,
  CornerDownLeft,
  X,
} from 'lucide-react';
import { aiService, Prediction, PredictionResponse } from '../services/ai';

// ─── Preset colour swatches ───────────────────────────────────────────────────

const SWATCHES = [
  { name: 'Chêne naturel',   hex: '#C19A6B' },
  { name: 'Noyer foncé',     hex: '#5C3D2E' },
  { name: 'Marbre blanc',    hex: '#F5F0E8' },
  { name: 'Ardoise grise',   hex: '#6B7280' },
  { name: 'Carrelage beige', hex: '#D4B896' },
  { name: 'Pierre noire',    hex: '#1F2937' },
  { name: 'Terre cuite',     hex: '#C2714F' },
  { name: 'Vert sauge',      hex: '#84A59D' },
  { name: 'Bleu nuit',       hex: '#1E3A5F' },
  { name: 'Blanc pur',       hex: '#FAFAFA' },
  { name: 'Or Premium',      hex: '#D4AF37' },
  { name: 'Anthracite',      hex: '#374151' },
];

// Each detected zone keeps its own color + opacity
interface ZoneStyle {
  color: string;   // hex
  opacity: number; // 0–1
}

// Manual zone defined by user-placed points
interface ManualZone {
  points: { x: number; y: number }[];
  closed: boolean;
}

type ColorMode = 'ai' | 'manual';

// ─── Point-in-polygon (ray casting) ──────────────────────────────────────────

function pointInPolygon(
  px: number,
  py: number,
  points: { x: number; y: number }[],
): boolean {
  let inside = false;
  for (let i = 0, j = points.length - 1; i < points.length; j = i++) {
    const xi = points[i].x, yi = points[i].y;
    const xj = points[j].x, yj = points[j].y;
    const intersect =
      yi > py !== yj > py &&
      px < ((xj - xi) * (py - yi)) / (yj - yi) + xi;
    if (intersect) inside = !inside;
  }
  return inside;
}

// ─── Distance helper ──────────────────────────────────────────────────────────

function dist(a: { x: number; y: number }, b: { x: number; y: number }) {
  return Math.sqrt((a.x - b.x) ** 2 + (a.y - b.y) ** 2);
}

// ─── Canvas overlay for AI mode ───────────────────────────────────────────────

interface OverlayProps {
  imageSrc: string;
  predictions: Prediction[];
  imageWidth: number;
  imageHeight: number;
  selectedIndex: number;
  zoneStyles: ZoneStyle[];
  previewMode: boolean;
  onZoneClick: (index: number) => void;
}

function FloorOverlay({
  imageSrc, predictions, imageWidth, imageHeight, selectedIndex, zoneStyles, previewMode, onZoneClick,
}: OverlayProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imgRef   = useRef<HTMLImageElement>(null);

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    const img    = imgRef.current;
    if (!canvas || !img || !img.complete) return;

    const ctx = canvas.getContext('2d')!;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

    const scaleX = canvas.width  / imageWidth;
    const scaleY = canvas.height / imageHeight;

    predictions.forEach((pred, i) => {
      if (pred.points.length < 2) return;
      const style      = zoneStyles[i] ?? { color: '#6366f1', opacity: 0.45 };
      const isSelected = i === selectedIndex;

      ctx.save();
      ctx.beginPath();
      ctx.moveTo(pred.points[0].x * scaleX, pred.points[0].y * scaleY);
      pred.points.slice(1).forEach((p) =>
        ctx.lineTo(p.x * scaleX, p.y * scaleY)
      );
      ctx.closePath();
      ctx.clip();

      ctx.globalAlpha = style.opacity;
      ctx.fillStyle   = style.color;
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.globalAlpha = 1;
      ctx.restore();

      if (!previewMode) {
        ctx.beginPath();
        ctx.moveTo(pred.points[0].x * scaleX, pred.points[0].y * scaleY);
        pred.points.slice(1).forEach((p) =>
          ctx.lineTo(p.x * scaleX, p.y * scaleY)
        );
        ctx.closePath();
        ctx.strokeStyle = isSelected ? 'rgba(255,255,255,0.95)' : 'rgba(255,255,255,0.3)';
        ctx.lineWidth   = isSelected ? 3 : 1.5;
        ctx.stroke();

        const cx = pred.points.reduce((s, p) => s + p.x, 0) / pred.points.length * scaleX;
        const cy = pred.points.reduce((s, p) => s + p.y, 0) / pred.points.length * scaleY;
        ctx.font         = 'bold 13px sans-serif';
        ctx.textAlign    = 'center';
        ctx.textBaseline = 'middle';
        ctx.shadowColor  = 'rgba(0,0,0,0.7)';
        ctx.shadowBlur   = 5;
        ctx.fillStyle    = '#ffffff';
        ctx.fillText(`Zone ${i + 1}`, cx, cy);
        ctx.shadowBlur   = 0;
      }
    });
  }, [predictions, imageWidth, imageHeight, selectedIndex, zoneStyles, previewMode]);

  useEffect(() => { draw(); }, [draw]);

  const handleCanvasClick = useCallback(
    (e: React.MouseEvent<HTMLCanvasElement>) => {
      const canvas = canvasRef.current;
      if (!canvas) return;

      const rect   = canvas.getBoundingClientRect();
      const scaleX = imageWidth  / rect.width;
      const scaleY = imageHeight / rect.height;
      const imgX = (e.clientX - rect.left) * scaleX;
      const imgY = (e.clientY - rect.top)  * scaleY;

      for (let i = predictions.length - 1; i >= 0; i--) {
        if (pointInPolygon(imgX, imgY, predictions[i].points)) {
          onZoneClick(i);
          return;
        }
      }
    },
    [predictions, imageWidth, imageHeight, onZoneClick],
  );

  return (
    <div className="relative w-full h-full flex items-center justify-center">
      <img ref={imgRef} src={imageSrc} className="hidden" onLoad={draw} alt="" />
      <canvas
        ref={canvasRef}
        width={imageWidth}
        height={imageHeight}
        onClick={handleCanvasClick}
        className="max-w-full max-h-[70vh] object-contain rounded-2xl shadow-2xl cursor-crosshair"
        style={{ display: 'block' }}
      />
    </div>
  );
}

// ─── Canvas overlay for Manual mode ───────────────────────────────────────────

interface ManualOverlayProps {
  imageSrc: string;
  manualZones: ManualZone[];
  zoneStyles: ZoneStyle[];
  selectedIndex: number;
  previewMode: boolean;
  onCanvasClick: (x: number, y: number, imgW: number, imgH: number) => void;
  onCanvasMouseMove: (x: number, y: number, imgW: number, imgH: number) => void;
  onZoneClick: (index: number) => void;
  cursorPos: { x: number; y: number } | null;
}

function ManualOverlay({
  imageSrc, manualZones, zoneStyles, selectedIndex, previewMode,
  onCanvasClick, onCanvasMouseMove, onZoneClick, cursorPos,
}: ManualOverlayProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const imgRef    = useRef<HTMLImageElement>(null);
  const [imgDims, setImgDims] = useState<{ w: number; h: number }>({ w: 800, h: 600 });

  const draw = useCallback(() => {
    const canvas = canvasRef.current;
    const img    = imgRef.current;
    if (!canvas || !img || !img.complete) return;

    canvas.width  = img.naturalWidth;
    canvas.height = img.naturalHeight;
    setImgDims({ w: img.naturalWidth, h: img.naturalHeight });

    const ctx = canvas.getContext('2d')!;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(img, 0, 0);

    // Draw closed zones with color fill
    manualZones.forEach((zone, i) => {
      if (zone.points.length < 2) return;
      const style = zoneStyles[i] ?? { color: '#6366f1', opacity: 0.45 };
      const isSelected = i === selectedIndex;

      if (zone.closed && zone.points.length >= 3) {
        // Fill
        ctx.save();
        ctx.beginPath();
        ctx.moveTo(zone.points[0].x, zone.points[0].y);
        zone.points.slice(1).forEach((p) => ctx.lineTo(p.x, p.y));
        ctx.closePath();
        ctx.clip();
        ctx.globalAlpha = style.opacity;
        ctx.fillStyle   = style.color;
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.globalAlpha = 1;
        ctx.restore();
      }

      if (!previewMode) {
        // Stroke outline
        ctx.beginPath();
        ctx.moveTo(zone.points[0].x, zone.points[0].y);
        zone.points.slice(1).forEach((p) => ctx.lineTo(p.x, p.y));
        if (zone.closed) ctx.closePath();
        ctx.strokeStyle = isSelected ? 'rgba(255,255,255,0.95)' : 'rgba(255,255,255,0.5)';
        ctx.lineWidth   = isSelected ? 3 : 1.5;
        ctx.setLineDash(zone.closed ? [] : [8, 4]);
        ctx.stroke();
        ctx.setLineDash([]);

        // Draw cursor-to-last-point line for open zone being drawn
        if (!zone.closed && isSelected && cursorPos && zone.points.length > 0) {
          const last = zone.points[zone.points.length - 1];
          ctx.beginPath();
          ctx.moveTo(last.x, last.y);
          ctx.lineTo(cursorPos.x, cursorPos.y);
          ctx.strokeStyle = 'rgba(212,175,55,0.6)';
          ctx.lineWidth = 2;
          ctx.setLineDash([6, 3]);
          ctx.stroke();
          ctx.setLineDash([]);
        }

        // Draw points
        zone.points.forEach((p, pi) => {
          const isFirst = pi === 0;
          const radius = isFirst && !zone.closed && isSelected ? 8 : 5;

          ctx.beginPath();
          ctx.arc(p.x, p.y, radius, 0, Math.PI * 2);
          ctx.fillStyle = isFirst && !zone.closed
            ? 'rgba(212,175,55,0.9)'
            : isSelected ? '#ffffff' : 'rgba(255,255,255,0.6)';
          ctx.fill();
          ctx.strokeStyle = 'rgba(0,0,0,0.4)';
          ctx.lineWidth = 1.5;
          ctx.stroke();

          // Snap indicator on first point
          if (isFirst && !zone.closed && isSelected && cursorPos && zone.points.length >= 3) {
            const d = dist(cursorPos, p);
            if (d < 20) {
              ctx.beginPath();
              ctx.arc(p.x, p.y, 14, 0, Math.PI * 2);
              ctx.strokeStyle = 'rgba(212,175,55,0.8)';
              ctx.lineWidth = 2.5;
              ctx.stroke();
            }
          }
        });

        // Zone label for closed zones
        if (zone.closed && zone.points.length >= 3) {
          const cx = zone.points.reduce((s, p) => s + p.x, 0) / zone.points.length;
          const cy = zone.points.reduce((s, p) => s + p.y, 0) / zone.points.length;
          ctx.font         = 'bold 13px sans-serif';
          ctx.textAlign    = 'center';
          ctx.textBaseline = 'middle';
          ctx.shadowColor  = 'rgba(0,0,0,0.7)';
          ctx.shadowBlur   = 5;
          ctx.fillStyle    = '#ffffff';
          ctx.fillText(`Zone ${i + 1}`, cx, cy);
          ctx.shadowBlur   = 0;
        }
      }
    });
  }, [manualZones, zoneStyles, selectedIndex, previewMode, cursorPos]);

  useEffect(() => { draw(); }, [draw]);

  const getImageCoords = useCallback((e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return null;
    const rect   = canvas.getBoundingClientRect();
    const scaleX = imgDims.w / rect.width;
    const scaleY = imgDims.h / rect.height;
    return {
      x: (e.clientX - rect.left) * scaleX,
      y: (e.clientY - rect.top)  * scaleY,
    };
  }, [imgDims]);

  const handleClick = useCallback((e: React.MouseEvent<HTMLCanvasElement>) => {
    const coords = getImageCoords(e);
    if (coords) onCanvasClick(coords.x, coords.y, imgDims.w, imgDims.h);
  }, [getImageCoords, onCanvasClick, imgDims]);

  const handleMouseMove = useCallback((e: React.MouseEvent<HTMLCanvasElement>) => {
    const coords = getImageCoords(e);
    if (coords) onCanvasMouseMove(coords.x, coords.y, imgDims.w, imgDims.h);
  }, [getImageCoords, onCanvasMouseMove, imgDims]);

  return (
    <div className="relative w-full h-full flex items-center justify-center">
      <img ref={imgRef} src={imageSrc} className="hidden" onLoad={draw} alt="" />
      <canvas
        ref={canvasRef}
        width={imgDims.w}
        height={imgDims.h}
        onClick={handleClick}
        onMouseMove={handleMouseMove}
        className="max-w-full max-h-[70vh] object-contain rounded-2xl shadow-2xl cursor-crosshair"
        style={{ display: 'block' }}
      />
    </div>
  );
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function hexToRgba(hex: string, alpha: number): string {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return `rgba(${r},${g},${b},${alpha})`;
}

// ─── Main component ───────────────────────────────────────────────────────────

const Simulator: React.FC = () => {
  const [imageSrc, setImageSrc]             = useState<string | null>(null);
  const [predictionData, setPredictionData] = useState<PredictionResponse | null>(null);
  const [selectedFloor, setSelectedFloor]   = useState(0);
  const [isLoading, setIsLoading]           = useState(false);
  const [error, setError]                   = useState<string | null>(null);
  const [zoneStyles, setZoneStyles]         = useState<ZoneStyle[]>([]);
  const [pickerHex, setPickerHex]           = useState('#C19A6B');
  const [previewMode, setPreviewMode]       = useState(false);
  const [clickedZone, setClickedZone]       = useState<number | null>(null);

  // ── Mode toggle ─────────────────────────────────────────────────────────────
  const [colorMode, setColorMode] = useState<ColorMode>('ai');

  // ── Manual mode state ───────────────────────────────────────────────────────
  const [manualZones, setManualZones]         = useState<ManualZone[]>([]);
  const [manualStyles, setManualStyles]       = useState<ZoneStyle[]>([]);
  const [manualSelected, setManualSelected]   = useState(0);
  const [manualPickerHex, setManualPickerHex] = useState('#C19A6B');
  const [cursorPos, setCursorPos]             = useState<{ x: number; y: number } | null>(null);
  const [isDrawing, setIsDrawing]             = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // ── Apply colour/opacity helpers (AI mode) ──────────────────────────────────

  const applyColor = useCallback((hex: string) => {
    setPickerHex(hex);
    setZoneStyles((prev) => {
      const next = [...prev];
      if (next[selectedFloor]) next[selectedFloor] = { ...next[selectedFloor], color: hex };
      return next;
    });
  }, [selectedFloor]);

  const applyOpacity = useCallback((val: number) => {
    setZoneStyles((prev) => {
      const next = [...prev];
      if (next[selectedFloor]) next[selectedFloor] = { ...next[selectedFloor], opacity: val };
      return next;
    });
  }, [selectedFloor]);

  const selectZone = useCallback((i: number) => {
    setSelectedFloor(i);
    setPickerHex(zoneStyles[i]?.color ?? '#C19A6B');
  }, [zoneStyles]);

  const handleZoneClick = useCallback((index: number) => {
    selectZone(index);
    setClickedZone(index);
    setTimeout(() => setClickedZone(null), 600);
  }, [selectZone]);

  // ── Apply colour/opacity helpers (Manual mode) ─────────────────────────────

  const applyManualColor = useCallback((hex: string) => {
    setManualPickerHex(hex);
    setManualStyles((prev) => {
      const next = [...prev];
      if (next[manualSelected]) next[manualSelected] = { ...next[manualSelected], color: hex };
      return next;
    });
  }, [manualSelected]);

  const applyManualOpacity = useCallback((val: number) => {
    setManualStyles((prev) => {
      const next = [...prev];
      if (next[manualSelected]) next[manualSelected] = { ...next[manualSelected], opacity: val };
      return next;
    });
  }, [manualSelected]);

  const selectManualZone = useCallback((i: number) => {
    setManualSelected(i);
    setManualPickerHex(manualStyles[i]?.color ?? '#C19A6B');
    setIsDrawing(!manualZones[i]?.closed);
  }, [manualStyles, manualZones]);

  // ── Manual zone canvas click ────────────────────────────────────────────────

  const handleManualCanvasClick = useCallback((x: number, y: number, imgW: number, imgH: number) => {
    const activeZone = manualZones[manualSelected];

    // If we are NOT drawing, check if clicked inside an existing closed zone
    if (!isDrawing) {
      for (let i = manualZones.length - 1; i >= 0; i--) {
        if (manualZones[i].closed && pointInPolygon(x, y, manualZones[i].points)) {
          selectManualZone(i);
          setClickedZone(i);
          setTimeout(() => setClickedZone(null), 600);
          return;
        }
      }
      return;
    }

    // If currently drawing an open zone
    if (activeZone && !activeZone.closed) {
      // Check snap to first point to close
      if (activeZone.points.length >= 3) {
        const first = activeZone.points[0];
        if (dist({ x, y }, first) < 20) {
          // Close the zone
          setManualZones((prev) => {
            const next = [...prev];
            next[manualSelected] = { ...next[manualSelected], closed: true };
            return next;
          });
          setIsDrawing(false);
          return;
        }
      }

      // Add a new point
      setManualZones((prev) => {
        const next = [...prev];
        next[manualSelected] = {
          ...next[manualSelected],
          points: [...next[manualSelected].points, { x, y }],
        };
        return next;
      });
    }
  }, [manualZones, manualSelected, isDrawing, selectManualZone]);

  const handleManualCanvasMouseMove = useCallback((x: number, y: number) => {
    setCursorPos({ x, y });
  }, []);

  // ── Start new manual zone ───────────────────────────────────────────────────

  const startNewManualZone = useCallback(() => {
    const idx = manualZones.length;
    setManualZones((prev) => [...prev, { points: [], closed: false }]);
    setManualStyles((prev) => [
      ...prev,
      { color: SWATCHES[idx % SWATCHES.length].hex, opacity: 0.45 },
    ]);
    setManualSelected(idx);
    setManualPickerHex(SWATCHES[idx % SWATCHES.length].hex);
    setIsDrawing(true);
  }, [manualZones.length]);

  // ── Delete manual zone ──────────────────────────────────────────────────────

  const deleteManualZone = useCallback((index: number) => {
    setManualZones((prev) => prev.filter((_, i) => i !== index));
    setManualStyles((prev) => prev.filter((_, i) => i !== index));
    if (manualSelected >= index && manualSelected > 0) {
      setManualSelected(manualSelected - 1);
    } else if (manualZones.length <= 1) {
      setManualSelected(0);
      setIsDrawing(false);
    }
  }, [manualSelected, manualZones.length]);

  // ── Close current zone manually (button) ────────────────────────────────────

  const closeCurrentZone = useCallback(() => {
    const zone = manualZones[manualSelected];
    if (zone && !zone.closed && zone.points.length >= 3) {
      setManualZones((prev) => {
        const next = [...prev];
        next[manualSelected] = { ...next[manualSelected], closed: true };
        return next;
      });
      setIsDrawing(false);
    }
  }, [manualZones, manualSelected]);

  // ── Undo last point ─────────────────────────────────────────────────────────

  const undoLastPoint = useCallback(() => {
    const zone = manualZones[manualSelected];
    if (zone && !zone.closed && zone.points.length > 0) {
      setManualZones((prev) => {
        const next = [...prev];
        next[manualSelected] = {
          ...next[manualSelected],
          points: next[manualSelected].points.slice(0, -1),
        };
        return next;
      });
    }
  }, [manualZones, manualSelected]);

  // ── Upload & predict ────────────────────────────────────────────────────────

  const handleFileUpload = useCallback(async (file: File) => {
    setError(null);
    setPredictionData(null);
    setSelectedFloor(0);
    setImageSrc(URL.createObjectURL(file));

    // Reset manual state too
    setManualZones([]);
    setManualStyles([]);
    setManualSelected(0);
    setIsDrawing(false);

    if (colorMode === 'ai') {
      setIsLoading(true);
      try {
        const data = await aiService.predictFloor(file);
        setPredictionData(data);
        const styles = data.predictions.map((_, i) => ({
          color:   SWATCHES[i % SWATCHES.length].hex,
          opacity: 0.45,
        }));
        setZoneStyles(styles);
        setPickerHex(styles[0]?.color ?? '#C19A6B');
      } catch (err: any) {
        setError(err.message ?? 'Une erreur est survenue.');
      } finally {
        setIsLoading(false);
      }
    }
  }, [colorMode]);

  // When switching to AI mode with an image already loaded, run detection
  const runAiDetection = useCallback(async () => {
    if (!imageSrc) return;
    setIsLoading(true);
    setError(null);
    try {
      // Re-fetch image as File from blob URL
      const resp = await fetch(imageSrc);
      const blob = await resp.blob();
      const file = new File([blob], 'image.jpg', { type: blob.type });
      const data = await aiService.predictFloor(file);
      setPredictionData(data);
      const styles = data.predictions.map((_, i) => ({
        color:   SWATCHES[i % SWATCHES.length].hex,
        opacity: 0.45,
      }));
      setZoneStyles(styles);
      setSelectedFloor(0);
      setPickerHex(styles[0]?.color ?? '#C19A6B');
    } catch (err: any) {
      setError(err.message ?? 'Une erreur est survenue.');
    } finally {
      setIsLoading(false);
    }
  }, [imageSrc]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleFileUpload(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (file?.type.startsWith('image/')) handleFileUpload(file);
  };

  const reset = () => {
    setImageSrc(null);
    setPredictionData(null);
    setZoneStyles([]);
    setManualZones([]);
    setManualStyles([]);
    setManualSelected(0);
    setIsDrawing(false);
    setError(null);
  };

  // ── Download ────────────────────────────────────────────────────────────────

  const downloadResult = () => {
    const canvas = document.querySelector('canvas') as HTMLCanvasElement | null;
    if (!canvas) return;
    const a = document.createElement('a');
    a.href = canvas.toDataURL('image/png');
    a.download = 'mur-colorise.png';
    a.click();
  };

  // ── Keyboard shortcut for undo ──────────────────────────────────────────────

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (colorMode === 'manual' && isDrawing) {
        if ((e.ctrlKey || e.metaKey) && e.key === 'z') {
          e.preventDefault();
          undoLastPoint();
        }
        if (e.key === 'Enter') {
          e.preventDefault();
          closeCurrentZone();
        }
        if (e.key === 'Escape') {
          e.preventDefault();
          // Cancel drawing: remove the current open zone
          const zone = manualZones[manualSelected];
          if (zone && !zone.closed) {
            deleteManualZone(manualSelected);
          }
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [colorMode, isDrawing, undoLastPoint, closeCurrentZone, manualZones, manualSelected, deleteManualZone]);

  // ── Render ──────────────────────────────────────────────────────────────────

  const hasPredictions     = !!predictionData && predictionData.predictions.length > 0;
  const hasManualZones     = manualZones.length > 0;
  const hasClosedManual    = manualZones.some((z) => z.closed);
  const currentActiveZone  = manualZones[manualSelected];

  // Active styles depend on mode
  const activeStyle = colorMode === 'ai'
    ? (zoneStyles[selectedFloor] ?? { color: '#C19A6B', opacity: 0.45 })
    : (manualStyles[manualSelected] ?? { color: '#C19A6B', opacity: 0.45 });
  const activePickerHex = colorMode === 'ai' ? pickerHex : manualPickerHex;
  const activeApplyColor = colorMode === 'ai' ? applyColor : applyManualColor;
  const activeApplyOpacity = colorMode === 'ai' ? applyOpacity : applyManualOpacity;

  const showColorPicker = colorMode === 'ai' ? hasPredictions : hasClosedManual;
  const showDownload    = colorMode === 'ai' ? hasPredictions : hasClosedManual;

  return (
    <div className="space-y-10 animate-fade-in">
      {/* Page header */}
      <div>
        <p className="text-[10px] font-black text-gold uppercase tracking-[0.3em] mb-2">
          Simulation Visuelle
        </p>
        <h2 className="text-5xl font-black text-slate-900 tracking-tight">
          Coloriseur de Mur AI
        </h2>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-10">

        {/* ── Left control panel ── */}
        <div className="lg:col-span-1">
          <div className="bg-white border border-slate-200 rounded-[2.5rem] p-8 shadow-xl shadow-slate-200/40 space-y-8">

            {/* Mode toggle */}
            <div className="space-y-3">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block ml-2">
                Méthode
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => {
                    setColorMode('ai');
                    if (imageSrc && !predictionData && !isLoading) runAiDetection();
                  }}
                  className={`flex flex-col items-center gap-2 px-3 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all border ${
                    colorMode === 'ai'
                      ? 'bg-slate-900 text-white border-slate-900 shadow-lg'
                      : 'bg-slate-50 text-slate-500 border-slate-100 hover:border-slate-300'
                  }`}
                >
                  <Cpu size={20} strokeWidth={2.5} />
                  <span>Détection IA</span>
                </button>
                <button
                  onClick={() => setColorMode('manual')}
                  className={`flex flex-col items-center gap-2 px-3 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all border ${
                    colorMode === 'manual'
                      ? 'bg-slate-900 text-white border-slate-900 shadow-lg'
                      : 'bg-slate-50 text-slate-500 border-slate-100 hover:border-slate-300'
                  }`}
                >
                  <PenTool size={20} strokeWidth={2.5} />
                  <span>Manuel</span>
                </button>
              </div>
            </div>

            {/* Step 1 – Upload */}
            <div className="space-y-4">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block ml-2">
                1. Photo de la pièce
              </label>

              {!imageSrc ? (
                <button
                  onClick={() => fileInputRef.current?.click()}
                  onDrop={handleDrop}
                  onDragOver={(e) => e.preventDefault()}
                  className="w-full aspect-square bg-slate-50 border-2 border-dashed border-slate-200 rounded-3xl flex flex-col items-center justify-center gap-4 hover:border-gold/50 transition-all group"
                >
                  <div className="w-16 h-16 rounded-full bg-white flex items-center justify-center text-slate-300 group-hover:text-gold transition-colors shadow-sm">
                    <Upload size={32} />
                  </div>
                  <p className="text-xs font-black text-slate-400 group-hover:text-slate-600 transition-colors px-6 text-center">
                    Glissez ou cliquez pour uploader
                  </p>
                </button>
              ) : (
                <div className="relative aspect-square rounded-3xl overflow-hidden border-2 border-slate-100 shadow-lg group">
                  <img src={imageSrc} className="w-full h-full object-cover" alt="Original" />
                  <div className="absolute inset-0 bg-slate-900/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <button onClick={reset} className="p-3 bg-white rounded-2xl text-rose-500 shadow-xl hover:scale-110 transition-transform">
                      <RefreshCcw size={20} strokeWidth={3} />
                    </button>
                  </div>
                </div>
              )}
              <input type="file" ref={fileInputRef} onChange={handleInputChange} accept="image/*" className="hidden" />
            </div>

            {/* ── AI MODE: Zone selector ── */}
            {colorMode === 'ai' && hasPredictions && (
              <div className="space-y-3">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block ml-2">
                  2. Zone à coloriser
                </label>
                <div className="flex items-center gap-2 px-3 py-2 bg-slate-50 rounded-2xl border border-slate-100">
                  <MousePointer2 size={13} className="text-gold flex-shrink-0" strokeWidth={2.5} />
                  <p className="text-[10px] font-bold text-slate-400">
                    Cliquez sur le mur dans l'image pour sélectionner
                  </p>
                </div>
                <div className="flex flex-col gap-2">
                  {predictionData!.predictions.map((pred, i) => (
                    <button
                      key={i}
                      onClick={() => selectZone(i)}
                      className={`flex items-center gap-3 px-4 py-3 rounded-2xl text-sm font-bold transition-all border ${
                        selectedFloor === i
                          ? 'bg-slate-900 text-white border-slate-900'
                          : 'bg-slate-50 text-slate-500 border-slate-100 hover:border-slate-300'
                      } ${clickedZone === i ? 'scale-[1.03]' : ''}`}
                    >
                      <span
                        className="w-4 h-4 rounded-full flex-shrink-0 border-2 border-white shadow"
                        style={{ backgroundColor: zoneStyles[i]?.color ?? '#ccc' }}
                      />
                      Zone {i + 1} — {pred.class}
                      <span className="ml-auto text-[10px] opacity-60">
                        {(pred.confidence * 100).toFixed(0)}%
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* ── MANUAL MODE: Zone manager ── */}
            {colorMode === 'manual' && imageSrc && !isLoading && (
              <div className="space-y-3">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block ml-2">
                  2. Zones manuelles
                </label>

                {/* Drawing instructions */}
                <div className="px-3 py-3 bg-amber-50 rounded-2xl border border-amber-100 space-y-1.5">
                  <div className="flex items-center gap-2">
                    <PenTool size={13} className="text-gold flex-shrink-0" strokeWidth={2.5} />
                    <p className="text-[10px] font-bold text-amber-700">Mode tracé manuel</p>
                  </div>
                  <p className="text-[10px] text-amber-600 leading-relaxed">
                    Cliquez sur l'image pour placer des points. Fermez la forme en cliquant sur le premier point ou appuyez <kbd className="px-1.5 py-0.5 bg-white rounded text-[9px] font-mono border border-amber-200">Entrée</kbd>.
                    <br />
                    <kbd className="px-1.5 py-0.5 bg-white rounded text-[9px] font-mono border border-amber-200">Ctrl+Z</kbd> annuler • <kbd className="px-1.5 py-0.5 bg-white rounded text-[9px] font-mono border border-amber-200">Échap</kbd> supprimer
                  </p>
                </div>

                {/* Zone list */}
                {hasManualZones && (
                  <div className="flex flex-col gap-2">
                    {manualZones.map((zone, i) => (
                      <div
                        key={i}
                        className={`flex items-center gap-3 px-4 py-3 rounded-2xl text-sm font-bold transition-all border ${
                          manualSelected === i
                            ? 'bg-slate-900 text-white border-slate-900'
                            : 'bg-slate-50 text-slate-500 border-slate-100 hover:border-slate-300'
                        } ${clickedZone === i ? 'scale-[1.03]' : ''}`}
                      >
                        <button
                          onClick={() => selectManualZone(i)}
                          className="flex items-center gap-3 flex-1 min-w-0"
                        >
                          <span
                            className="w-4 h-4 rounded-full flex-shrink-0 border-2 border-white shadow"
                            style={{ backgroundColor: manualStyles[i]?.color ?? '#ccc' }}
                          />
                          <span className="truncate">
                            Zone {i + 1}
                            {!zone.closed && (
                              <span className="ml-2 text-[9px] opacity-70">
                                ({zone.points.length} pts)
                              </span>
                            )}
                          </span>
                          {zone.closed && (
                            <Check size={12} className="text-emerald-400 ml-1" strokeWidth={3} />
                          )}
                          {!zone.closed && (
                            <span className="text-[9px] ml-1 opacity-60 italic">en cours…</span>
                          )}
                        </button>
                        <button
                          onClick={(e) => { e.stopPropagation(); deleteManualZone(i); }}
                          className={`p-1 rounded-lg transition-all flex-shrink-0 ${
                            manualSelected === i
                              ? 'hover:bg-white/20 text-white/60 hover:text-white'
                              : 'hover:bg-rose-50 text-slate-300 hover:text-rose-400'
                          }`}
                          title="Supprimer la zone"
                        >
                          <Trash2 size={14} strokeWidth={2.5} />
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                {/* Action buttons for manual mode */}
                <div className="flex gap-2">
                  {/* New zone button */}
                  <button
                    onClick={startNewManualZone}
                    disabled={isDrawing}
                    className={`flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all border ${
                      isDrawing
                        ? 'bg-slate-50 text-slate-300 border-slate-100 cursor-not-allowed'
                        : 'bg-gold/10 text-gold border-gold/20 hover:bg-gold/20 hover:border-gold/40'
                    }`}
                  >
                    <Plus size={15} strokeWidth={3} />
                    Nouvelle zone
                  </button>

                  {/* Close zone button */}
                  {isDrawing && currentActiveZone && !currentActiveZone.closed && currentActiveZone.points.length >= 3 && (
                    <button
                      onClick={closeCurrentZone}
                      className="flex items-center justify-center gap-2 px-4 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all border bg-emerald-50 text-emerald-600 border-emerald-200 hover:bg-emerald-100"
                    >
                      <CornerDownLeft size={14} strokeWidth={3} />
                      Fermer
                    </button>
                  )}
                </div>

                {/* Undo button when drawing */}
                {isDrawing && currentActiveZone && !currentActiveZone.closed && currentActiveZone.points.length > 0 && (
                  <button
                    onClick={undoLastPoint}
                    className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-2xl text-[10px] font-bold uppercase tracking-widest transition-all border bg-slate-50 text-slate-500 border-slate-100 hover:border-slate-300"
                  >
                    <X size={13} strokeWidth={3} />
                    Annuler le dernier point
                  </button>
                )}
              </div>
            )}

            {/* Step 3 – Color picker (shared UI, different handlers) */}
            {showColorPicker && (
              <div className="space-y-4">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block ml-2">
                  3. Couleur
                </label>

                <div className="grid grid-cols-4 gap-2">
                  {SWATCHES.map((s) => (
                    <button
                      key={s.hex}
                      onClick={() => activeApplyColor(s.hex)}
                      title={s.name}
                      className={`aspect-square rounded-xl border-4 transition-all relative hover:scale-110 ${
                        activeStyle.color === s.hex
                          ? 'border-slate-900 scale-110 shadow-lg'
                          : 'border-transparent'
                      }`}
                      style={{ backgroundColor: s.hex }}
                    >
                      {activeStyle.color === s.hex && (
                        <div className="absolute inset-0 flex items-center justify-center">
                          <Check size={13} strokeWidth={3} className="text-white drop-shadow" />
                        </div>
                      )}
                    </button>
                  ))}
                </div>

                <div className="flex items-center gap-3">
                  <input
                    type="color"
                    value={activePickerHex}
                    onChange={(e) => activeApplyColor(e.target.value)}
                    className="w-10 h-10 rounded-xl cursor-pointer border border-slate-200 p-0.5 flex-shrink-0"
                  />
                  <div className="flex-1">
                    <p className="text-[10px] font-bold text-slate-400 mb-1">Hex personnalisé</p>
                    <input
                      type="text"
                      value={activePickerHex}
                      onChange={(e) => {
                        const v = e.target.value;
                        if (colorMode === 'ai') setPickerHex(v);
                        else setManualPickerHex(v);
                        if (/^#[0-9A-Fa-f]{6}$/.test(v)) activeApplyColor(v);
                      }}
                      className="w-full border border-slate-200 rounded-xl px-3 py-1.5 text-sm font-mono text-slate-700 focus:outline-none focus:border-gold"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <p className="text-[10px] font-bold text-slate-400 ml-1">Opacité</p>
                    <p className="text-[10px] font-black text-slate-600 mr-1">
                      {Math.round(activeStyle.opacity * 100)}%
                    </p>
                  </div>
                  <input
                    type="range"
                    min={0} max={1} step={0.01}
                    value={activeStyle.opacity}
                    onChange={(e) => activeApplyOpacity(Number(e.target.value))}
                    className="w-full accent-gold"
                  />
                  <div
                    className="h-2 rounded-full border border-slate-100"
                    style={{ background: `linear-gradient(to right, transparent, ${activeStyle.color})` }}
                  />
                </div>

                <div
                  className="h-12 rounded-2xl border border-slate-100 shadow-inner transition-all"
                  style={{ backgroundColor: hexToRgba(activeStyle.color, activeStyle.opacity) }}
                />
              </div>
            )}

            {/* Download */}
            {showDownload && (
              <button
                onClick={downloadResult}
                className="w-full bg-gold text-white font-black py-5 rounded-2xl shadow-xl shadow-gold/20 hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center justify-center gap-3 uppercase text-xs tracking-widest"
              >
                <Download size={20} strokeWidth={3} />
                Télécharger
              </button>
            )}
          </div>
        </div>

        {/* ── Right canvas panel ── */}
        <div className="lg:col-span-3">
          <div className="bg-white border border-slate-200 rounded-[3rem] p-10 shadow-xl shadow-slate-200/40 min-h-[600px] flex flex-col">

            {/* Panel header */}
            <div className="flex items-center gap-4 mb-8">
              <div className="w-12 h-12 rounded-xl bg-slate-50 flex items-center justify-center text-gold">
                {colorMode === 'ai' ? <Palette size={24} /> : <PenTool size={24} />}
              </div>
              <div>
                <h3 className="text-xl font-black text-slate-900">
                  {colorMode === 'ai' ? 'Aperçu en temps réel' : 'Tracé manuel'}
                </h3>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                  {colorMode === 'ai'
                    ? 'Colorisation par zone détectée'
                    : 'Placez des points pour définir la zone'
                  }
                </p>
              </div>
              {/* Status badges */}
              <div className="ml-auto flex items-center gap-3">
                {colorMode === 'ai' && hasPredictions && (
                  <div className="flex items-center gap-2 bg-slate-50 border border-slate-100 rounded-2xl px-4 py-2">
                    <span
                      className="w-3 h-3 rounded-full border border-white shadow"
                      style={{ backgroundColor: activeStyle.color }}
                    />
                    <span className="text-[10px] font-black text-slate-600 uppercase tracking-widest">
                      Zone {selectedFloor + 1} active
                    </span>
                  </div>
                )}
                {colorMode === 'manual' && hasManualZones && (
                  <div className="flex items-center gap-2 bg-slate-50 border border-slate-100 rounded-2xl px-4 py-2">
                    <span
                      className="w-3 h-3 rounded-full border border-white shadow"
                      style={{ backgroundColor: activeStyle.color }}
                    />
                    <span className="text-[10px] font-black text-slate-600 uppercase tracking-widest">
                      Zone {manualSelected + 1} {isDrawing ? '(tracé…)' : 'active'}
                    </span>
                  </div>
                )}
                {/* Preview toggle */}
                {(hasPredictions || hasClosedManual) && (
                  <button
                    onClick={() => setPreviewMode((v) => !v)}
                    className={`flex items-center gap-2 px-5 py-2 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all border ${
                      previewMode
                        ? 'bg-gold text-white border-gold shadow-lg shadow-gold/20'
                        : 'bg-slate-50 text-slate-600 border-slate-200 hover:border-slate-400'
                    }`}
                  >
                    {previewMode ? (
                      <><Check size={13} strokeWidth={3} /> Aperçu activé</>
                    ) : (
                      <><Palette size={13} strokeWidth={2.5} /> Voir le résultat</>
                    )}
                  </button>
                )}
              </div>
            </div>

            {/* Canvas area */}
            <div className="flex-1 relative rounded-[2rem] overflow-hidden bg-slate-50 border border-slate-100 flex items-center justify-center min-h-[400px]">

              {/* Loading spinner */}
              {isLoading && (
                <div className="absolute inset-0 z-20 bg-white/60 backdrop-blur-sm flex flex-col items-center justify-center gap-6">
                  <div className="w-20 h-20 border-4 border-gold/20 border-t-gold rounded-full animate-spin" />
                  <div className="text-center">
                    <p className="text-xl font-black text-slate-900">Analyse en cours…</p>
                    <p className="text-xs font-bold text-slate-400 mt-2">Détection des surfaces de Mur</p>
                  </div>
                </div>
              )}

              {/* Error */}
              {error && !isLoading && (
                <div className="flex flex-col items-center gap-3 text-center p-8">
                  <AlertCircle size={48} className="text-rose-400" strokeWidth={1.5} />
                  <p className="text-sm font-black text-rose-500">{error}</p>
                  <button onClick={reset} className="mt-2 px-6 py-2 bg-slate-100 rounded-xl text-[10px] font-black uppercase tracking-widest text-slate-600 hover:bg-slate-200 transition">
                    Réessayer
                  </button>
                </div>
              )}

              {/* Empty state */}
              {!imageSrc && !isLoading && !error && (
                <div className="text-center space-y-4 opacity-30">
                  <Camera size={80} strokeWidth={1} className="mx-auto text-slate-400" />
                  <p className="text-sm font-black text-slate-400 uppercase tracking-widest">
                    Uploadez une photo pour commencer
                  </p>
                </div>
              )}

              {/* Preview during load */}
              {imageSrc && isLoading && (
                <img src={imageSrc} className="max-w-full max-h-[70vh] object-contain opacity-30" alt="" />
              )}

              {/* ✅ AI mode overlay */}
              {colorMode === 'ai' && imageSrc && hasPredictions && !isLoading && !error && (
                <FloorOverlay
                  imageSrc={imageSrc}
                  predictions={predictionData!.predictions}
                  imageWidth={predictionData!.image_width}
                  imageHeight={predictionData!.image_height}
                  selectedIndex={selectedFloor}
                  zoneStyles={zoneStyles}
                  previewMode={previewMode}
                  onZoneClick={handleZoneClick}
                />
              )}

              {/* ✅ Manual mode overlay */}
              {colorMode === 'manual' && imageSrc && !isLoading && !error && (
                <ManualOverlay
                  imageSrc={imageSrc}
                  manualZones={manualZones}
                  zoneStyles={manualStyles}
                  selectedIndex={manualSelected}
                  previewMode={previewMode}
                  onCanvasClick={handleManualCanvasClick}
                  onCanvasMouseMove={handleManualCanvasMouseMove}
                  onZoneClick={(i) => {
                    selectManualZone(i);
                    setClickedZone(i);
                    setTimeout(() => setClickedZone(null), 600);
                  }}
                  cursorPos={isDrawing ? cursorPos : null}
                />
              )}

              {/* No detections (AI mode) */}
              {colorMode === 'ai' && imageSrc && !hasPredictions && !isLoading && !error && (
                <div className="flex flex-col items-center gap-4 p-8 text-center">
                  <img src={imageSrc} className="max-w-full max-h-[50vh] object-contain rounded-2xl shadow-lg" alt="Uploaded" />
                  <p className="text-sm font-bold text-slate-400">Aucun Mur détecté dans cette image.</p>
                  <button
                    onClick={() => setColorMode('manual')}
                    className="mt-2 px-6 py-2.5 bg-gold/10 text-gold border border-gold/20 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-gold/20 transition"
                  >
                    <PenTool size={13} className="inline mr-2" strokeWidth={2.5} />
                    Essayer en mode manuel
                  </button>
                </div>
              )}

              {/* Manual mode empty – image loaded but no zones yet */}
              {colorMode === 'manual' && imageSrc && !hasManualZones && !isLoading && !error && (
                <div className="absolute inset-0 z-10 flex items-center justify-center pointer-events-none">
                  <div className="bg-white/90 backdrop-blur-sm rounded-2xl px-6 py-4 shadow-lg border border-slate-200 text-center">
                    <PenTool size={24} className="mx-auto text-gold mb-2" />
                    <p className="text-sm font-bold text-slate-600">
                      Cliquez sur « Nouvelle zone » puis tracez sur l'image
                    </p>
                  </div>
                </div>
              )}
            </div>

            <div className="mt-8 flex items-center gap-4 text-xs font-bold text-slate-400 border-t border-slate-50 pt-8">
              <Layers size={18} />
              <p>
                {colorMode === 'ai'
                  ? "Cliquez directement sur une zone dans l'image pour la sélectionner, ou utilisez les boutons de zone à gauche. Ajustez la couleur et l'opacité pour un rendu réaliste."
                  : "Mode manuel : créez une zone, placez des points sur le mur, fermez la forme, puis colorisez. Ctrl+Z pour annuler, Entrée pour fermer, Échap pour supprimer."
                }
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Simulator;